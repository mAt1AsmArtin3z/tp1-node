console.log("Mi primer programa en Node.js")
console.log("Fin")